import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class AppMain {
    public JFrame mainFrm;
    public JPanel bottomPnl;
    public JLabel lbl1, lbl2, lbl3, lbl4, lbl5, lbl6, lbl7, lbl8, lbl9, lbl10;
    public JButton imgBtn2, imgBtn3, imgBtn4, imgBtn5, imgBtn6, imgBtn7;
    public JButton pnlBtn1, pnlBtn2, pnlBtn3, pnlBtn4 ;

    public JPanel pnl1, pnl2, pnl3, pnl4, pnl5, pnl6;
    public JLabel lblB1, lblB2, lblB3, lblB4, lblB5, lblB6, lblB7, lblB8, lblB9, lblB10;
    public JButton pnl2imgBtn2, pnl2imgBtn3, pnl2imgBtn4, pnl2imgBtn5, pnl2imgBtn6, pnl2imgBtn7;
    public JButton pnlBottomBtn1, pnlBottomBtn2, pnlBottomBtn3, pnlBottomBtn4;


    public AppMain() {

        //MAIN FRAME---------------------------------------------------------------------------------------------------
        mainFrm = new JFrame("Homepage");
        mainFrm.getContentPane().setBackground(Color.decode("#f7f3eb"));
        mainFrm.setSize(520, 890);
        mainFrm.setLayout(null);
        mainFrm.setLocationRelativeTo(null);
        mainFrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrm.setResizable(false);

        //BOTTOM PANEL--------------------------------------------------------------------------------------------------
        bottomPnl = new JPanel();
        bottomPnl.setBackground(Color.decode("#d99b9b"));
        bottomPnl.setBounds(0, 780, 550, 80);
        bottomPnl.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 0));

        pnlBtn1 = new JButton(new ImageIcon("Files/1.png"));
        pnlBtn1.setPreferredSize(new Dimension(100, 100));
        pnlBtn1.setContentAreaFilled(false);
        pnlBtn1.setBorderPainted(false);
        pnlBtn1.addActionListener(e -> {
            pnl1.setVisible(true);
            pnl2.setVisible(false);
            pnl3.setVisible(false);
            pnl4.setVisible(false);
            pnl5.setVisible(false);
            pnl6.setVisible(false);

        });

        pnlBtn2 = new JButton(new ImageIcon("Files/4.png"));
        pnlBtn2.setPreferredSize(new Dimension(100, 100));
        pnlBtn2.setContentAreaFilled(false);
        pnlBtn2.setBorderPainted(false);
        pnlBtn2.addActionListener(e -> {
            pnl1.setVisible(false);
            pnl2.setVisible(true);
            pnl3.setVisible(false);
            pnl4.setVisible(false);
            pnl5.setVisible(false);
            pnl6.setVisible(false);

        });

        pnlBtn3 = new JButton(new ImageIcon("Files/6.png"));
        pnlBtn3.setPreferredSize(new Dimension(100, 100));
        pnlBtn3.setContentAreaFilled(false);
        pnlBtn3.setBorderPainted(false);
        pnlBtn3.addActionListener(e -> {
            pnl1.setVisible(false);
            pnl2.setVisible(false);
            pnl3.setVisible(true);
            pnl4.setVisible(false);
            pnl5.setVisible(false);
            pnl6.setVisible(false);

        });

        pnlBtn4 = new JButton(new ImageIcon("Files/8.png"));
        pnlBtn4.setPreferredSize(new Dimension(100, 100));
        pnlBtn4.setContentAreaFilled(false);
        pnlBtn4.setBorderPainted(false);
        pnlBtn4.addActionListener(e -> {
            pnl1.setVisible(false);
            pnl2.setVisible(false);
            pnl3.setVisible(false);
            pnl4.setVisible(true);
            pnl5.setVisible(false);
            pnl6.setVisible(false);

        });

// Mouse listeners to change icon on click
        /*pnlBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlBtn1.setIcon(new ImageIcon("Files/Icon1_clicked.png"));
            }
        });

        pnlBtn2.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlBtn2.setIcon(new ImageIcon("Files/Icon2_clicked.png"));
            }
        });

        pnlBtn3.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlBtn3.setIcon(new ImageIcon("Files/Icon3_clicked.png"));
            }
        });

        pnlBtn4.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlBtn4.setIcon(new ImageIcon("Files/Icon4_clicked.png"));
            }
        });*/

        bottomPnl.add(pnlBtn1);
        bottomPnl.add(pnlBtn2);
        bottomPnl.add(pnlBtn3);
        bottomPnl.add(pnlBtn4);

        mainFrm.add(bottomPnl);
        //----------------------------------------------------------------------------------------------------------

        pnl1 = new JPanel();
        pnl1.setBackground(Color.WHITE);
        pnl1.setBounds(0, 0, 510, 780);
        pnl1.setLayout(null);
        pnl1.setVisible(true);

        lbl1 = new JLabel(getGreetingMessage("username"));
        lbl1.setFont(new Font("Roboto", Font.BOLD, 24));
        lbl1.setForeground(Color.BLACK);
        lbl1.setBounds(25, 20, 540, 60);
        pnl1.add(lbl1);

        JButton imageButton = new JButton(new ImageIcon("Files/YourAccount.png"));
        imageButton.setPreferredSize(new Dimension(100, 100));
        imageButton.setContentAreaFilled(false);
        imageButton.setBorderPainted(false);
        imageButton.setBounds(410, 20, 80, 80);
        pnl1.add(imageButton);
        imageButton.addActionListener(e -> {
            pnl1.setVisible(false);
            pnl2.setVisible(false);
            pnl3.setVisible(false);
            pnl4.setVisible(false);
            pnl5.setVisible(true);
        });

        lbl2 = new JLabel("SHORTCUTS");
        lbl2.setFont(new Font("Roboto", Font.PLAIN, 18));
        lbl2.setForeground(Color.BLACK);
        lbl2.setBounds(25, 100, 540, 60);
        pnl1.add(lbl2);

        imgBtn2 = new JButton(new ImageIcon("Files/LiveView.png"));
        imgBtn2.setContentAreaFilled(false);
        imgBtn2.setBorderPainted(false);
        imgBtn2.setBounds(20, 150, 100, 100);
        pnl1.add(imgBtn2);

        imgBtn3 = new JButton(new ImageIcon("Files/location.png"));
        imgBtn3.setContentAreaFilled(false);
        imgBtn3.setBorderPainted(false);
        imgBtn3.setBounds(140, 150, 100, 100);
        pnl1.add(imgBtn3);
        imgBtn3.addActionListener(e -> {
            pnl1.setVisible(false);
            pnl2.setVisible(false);
            pnl3.setVisible(false);
            pnl4.setVisible(false);
            pnl5.setVisible(false);
            pnl6.setVisible(true);




        });

        imgBtn4 = new JButton(new ImageIcon("Files/doc.png"));
        imgBtn4.setContentAreaFilled(false);
        imgBtn4.setBorderPainted(false);
        imgBtn4.setBounds(260, 150, 100, 100);
        pnl1.add(imgBtn4);


        imgBtn5 = new JButton(new ImageIcon("Files/dashboard.png"));
        imgBtn5.setContentAreaFilled(false);
        imgBtn5.setBorderPainted(false);
        imgBtn5.setBounds(380, 150, 100, 100);
        pnl1.add(imgBtn5);
        imgBtn5.addActionListener(e -> {
                    pnl1.setVisible(false);
                    pnl2.setVisible(false);
                    pnl3.setVisible(true);
                    pnl4.setVisible(false);
                });

        lbl3 = new JLabel("Live View");
        lbl3.setFont(new Font("Roboto", Font.BOLD, 17));
        lbl3.setForeground(Color.BLACK);
        lbl3.setBounds(30, 255, 100, 20);
        pnl1.add(lbl3);

        lbl4 = new JLabel("Location Track");
        lbl4.setFont(new Font("Roboto", Font.BOLD, 17));
        lbl4.setForeground(Color.BLACK);
        lbl4.setBounds(130, 255, 150, 20);
        pnl1.add(lbl4);

        lbl5 = new JLabel("Contact Doctor");
        lbl5.setFont(new Font("Roboto", Font.BOLD, 17));
        lbl5.setForeground(Color.BLACK);
        lbl5.setBounds(255, 255, 150, 20);
        pnl1.add(lbl5);

        lbl6 = new JLabel("Dashboard");
        lbl6.setFont(new Font("Roboto", Font.BOLD, 17));
        lbl6.setForeground(Color.BLACK);
        lbl6.setBounds(385, 255, 150, 20);
        pnl1.add(lbl6);


        lbl7 = new JLabel("VITALS");
        lbl7.setFont(new Font("Roboto", Font.PLAIN, 18));
        lbl7.setForeground(Color.BLACK);
        lbl7.setBounds(25, 270, 540, 60);
        pnl1.add(lbl7);

        imgBtn6 = new JButton(new ImageIcon("Files/vitals.png"));
        imgBtn6.setContentAreaFilled(false);
        imgBtn6.setBorderPainted(false);
        imgBtn6.setBounds(20, 310, 480, 200);
        pnl1.add(imgBtn6);
        imgBtn6.addActionListener(e -> {
            pnl1.setVisible(false);
            pnl2.setVisible(true);
            pnl3.setVisible(false);
            pnl4.setVisible(false);
        });

        lbl8 = new JLabel("LOCATION");
        lbl8.setFont(new Font("Roboto", Font.PLAIN, 18));
        lbl8.setForeground(Color.BLACK);
        lbl8.setBounds(25, 490, 540, 60);
        pnl1.add(lbl8);



        lbl9 = new JLabel("Near Bashundhara, Dhaka");
        lbl9.setFont(new Font("Roboto", Font.BOLD, 20));
        lbl9.setForeground(Color.BLACK);
        lbl9.setBounds(25, 510, 540, 60);
        pnl1.add(lbl9);

        imgBtn7 = new JButton(new ImageIcon("Files/location2.png"));
        imgBtn7.setContentAreaFilled(false);
        imgBtn7.setBorderPainted(false);
        imgBtn7.setBounds(40, 560, 450, 200);
        pnl1.add(imgBtn7);

        // PANEL 2 -----------------------------------------------------------------------------------------------------
        pnl2 = new JPanel();
        pnl2.setBackground(Color.WHITE);
        pnl2.setBounds(0, 0, 510, 780);
        pnl2.setLayout(null);
        pnl2.setVisible(false);

        lblB1 = new JLabel("Tools");
        lblB1.setFont(new Font("Roboto", Font.BOLD, 24));
        lblB1.setForeground(Color.BLACK);
        lblB1.setBounds(25, 20, 540, 60);
        pnl2.add(lblB1);

        pnl2imgBtn2 = new JButton(new ImageIcon("Files/pnl2/1.png"));
        pnl2imgBtn2.setPreferredSize(new Dimension(210, 150));
        pnl2imgBtn2.setContentAreaFilled(false);
        pnl2imgBtn2.setBorderPainted(false);
        pnl2imgBtn2.setBounds(30, 100, 210, 150);
        pnl2.add(pnl2imgBtn2);

        pnl2imgBtn3 = new JButton(new ImageIcon("Files/pnl2/2.png"));
        pnl2imgBtn3.setPreferredSize(new Dimension(210, 150));
        pnl2imgBtn3.setContentAreaFilled(false);
        pnl2imgBtn3.setBorderPainted(false);
        pnl2imgBtn3.setBounds(270, 100, 210, 150);
        pnl2.add(pnl2imgBtn3);

        pnl2imgBtn4 = new JButton(new ImageIcon("Files/pnl2/3.png"));
        pnl2imgBtn4.setPreferredSize(new Dimension(210, 150));
        pnl2imgBtn4.setContentAreaFilled(false);
        pnl2imgBtn4.setBorderPainted(false);
        pnl2imgBtn4.setBounds(30, 280, 210, 150);
        pnl2.add(pnl2imgBtn4);

        pnl2imgBtn5 = new JButton(new ImageIcon("Files/pnl2/4.png"));
        pnl2imgBtn5.setPreferredSize(new Dimension(210, 150));
        pnl2imgBtn5.setContentAreaFilled(false);
        pnl2imgBtn5.setBorderPainted(false);
        pnl2imgBtn5.setBounds(270, 280, 210, 150);
        pnl2.add(pnl2imgBtn5);

        pnl2imgBtn6 = new JButton(new ImageIcon("Files/pnl2/5.png"));
        pnl2imgBtn6.setPreferredSize(new Dimension(210, 150));
        pnl2imgBtn6.setContentAreaFilled(false);
        pnl2imgBtn6.setBorderPainted(false);
        pnl2imgBtn6.setBounds(30, 460, 210, 150);
        pnl2.add(pnl2imgBtn6);

        pnl2imgBtn7 = new JButton(new ImageIcon("Files/pnl2/6.png"));
        pnl2imgBtn7.setPreferredSize(new Dimension(210, 150));
        pnl2imgBtn7.setContentAreaFilled(false);
        pnl2imgBtn7.setBorderPainted(false);
        pnl2imgBtn7.setBounds(270, 460, 210, 150);
        pnl2.add(pnl2imgBtn7);


        //PANEL 3 ------------------------------------------------------------------------------------------------------
        pnl3 = new JPanel();
        pnl3.setLayout(null);
        pnl3.setBackground(Color.WHITE);
        pnl3.setBounds(0, 0, 510, 780);
        pnl3.setVisible(false);

        JLabel lblDash = new JLabel("Dashboard");
        lblDash.setFont(new Font("Roboto", Font.BOLD, 24));
        lblDash.setForeground(Color.BLACK);
        lblDash.setBounds(25, 20, 540, 60);
        pnl3.add(lblDash);

        ImageIcon imageIcon = new ImageIcon("Files/HeartrateDaily.gif");
        JLabel imageLabel = new JLabel(imageIcon);
        imageLabel.setVisible(true);
        imageLabel.setBounds(20, 190, 450, 350);
        pnl3.add(imageLabel);

        ImageIcon imageIcon2 = new ImageIcon("Files/heartrateWeekly.gif");
        JLabel imageLabel2 = new JLabel(imageIcon2);
        imageLabel2.setVisible(false);
        imageLabel2.setBounds(20, 190, 450, 300);
        pnl3.add(imageLabel2);

        JButton btnDaily = new JButton(new ImageIcon("Files/DAILY.png"));
        btnDaily.setPreferredSize(new Dimension(100, 100));
        btnDaily.setContentAreaFilled(false);
        btnDaily.setBorderPainted(false);
        btnDaily.setBounds(20, 150, 80, 40);
        pnl3.add(btnDaily);
        btnDaily.addActionListener(e -> {
            imageLabel.setVisible(true);
            imageLabel2.setVisible(false);

        });

        JButton btnWeekly = new JButton(new ImageIcon("Files/WEEKLY.png"));
        btnWeekly.setPreferredSize(new Dimension(100, 100));
        btnWeekly.setContentAreaFilled(false);
        btnWeekly.setBorderPainted(false);
        btnWeekly.setBounds(220, 150, 80, 40);
        pnl3.add(btnWeekly);
        btnWeekly.addActionListener(e -> {
            imageLabel.setVisible(false);
            imageLabel2.setVisible(true);

        });

        JButton btnMonthly = new JButton(new ImageIcon("Files/MONTHLY.png"));
        btnMonthly.setPreferredSize(new Dimension(100, 100));
        btnMonthly.setContentAreaFilled(false);
        btnMonthly.setBorderPainted(false);
        btnMonthly.setBounds(410, 150, 100, 40);
        pnl3.add(btnMonthly);



        ImageIcon imageIcon3 = new ImageIcon("Files/suggestions.png");
        JLabel imageLabel3 = new JLabel(imageIcon3);
        imageLabel3.setVisible(true);
        imageLabel3.setBounds(40, 500, 450, 300);
        pnl3.add(imageLabel3);

        // PANEL 4 -----------------------------------------------------------------------------------------------------
        pnl4 = new JPanel();
        pnl4.setLayout(null);
        pnl4.setBounds(0, 0, 550, 780);
        pnl4.setBackground(Color.WHITE);
        pnl4.setVisible(false);

        // Title
        JLabel lblNoti = new JLabel("Notifications");
        lblNoti.setFont(new Font("Roboto", Font.BOLD, 24));
        lblNoti.setForeground(Color.BLACK);
        lblNoti.setBounds(25, 20, 540, 60);
        pnl4.add(lblNoti);

        JButton btnNoti1 = new JButton(new ImageIcon("Files/Notifications/1.png"));
        btnNoti1.setContentAreaFilled(false);
        btnNoti1.setBorderPainted(false);
        btnNoti1.setBounds(60, 100, 400, 200);
        pnl4.add(btnNoti1);

        JButton btnNoti2 = new JButton(new ImageIcon("Files/Notifications/2.png"));
        btnNoti2.setContentAreaFilled(false);
        btnNoti2.setBorderPainted(false);
        btnNoti2.setBounds(60, 320, 400, 200);
        pnl4.add(btnNoti2);

        JButton btnNoti3 = new JButton(new ImageIcon("Files/Notifications/3.png"));
        btnNoti3.setContentAreaFilled(false);
        btnNoti3.setBorderPainted(false);
        btnNoti3.setBounds(60, 540, 400, 200);
        pnl4.add(btnNoti3);

        /*JPanel bottomPnl = new JPanel();
        bottomPnl.setBackground(Color.decode("#d99b9b"));
        bottomPnl.setBounds(0, 780, 550, 150);
        bottomPnl.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 0));

        JButton pnlBtn1 = new JButton(new ImageIcon("Files/1.png"));
        pnlBtn1.setPreferredSize(new Dimension(100, 100));
        pnlBtn1.setContentAreaFilled(false);
        pnlBtn1.setBorderPainted(false);

        JButton pnlBtn2 = new JButton(new ImageIcon("Files/4.png"));
        pnlBtn2.setPreferredSize(new Dimension(100, 100));
        pnlBtn2.setContentAreaFilled(false);
        pnlBtn2.setBorderPainted(false);

        JButton pnlBtn3 = new JButton(new ImageIcon("Files/6.png"));
        pnlBtn3.setPreferredSize(new Dimension(100, 100));
        pnlBtn3.setContentAreaFilled(false);
        pnlBtn3.setBorderPainted(false);

        JButton pnlBtn4 = new JButton(new ImageIcon("Files/8.png"));
        pnlBtn4.setPreferredSize(new Dimension(100, 100));
        pnlBtn4.setContentAreaFilled(false);
        pnlBtn4.setBorderPainted(false);

        bottomPnl.add(pnlBtn1);
        bottomPnl.add(pnlBtn2);
        bottomPnl.add(pnlBtn3);
        bottomPnl.add(pnlBtn4);*/

        // PANEL 5----------------------------------------------------------------------------------------------------
        pnl5 = new JPanel();
        pnl5.setLayout(null);
        pnl5.setBackground(Color.WHITE);
        pnl5.setBounds(0, 0, 510, 780);
        pnl5.setVisible(false);


        JButton btnAcc = new JButton(new ImageIcon("Files/About User.png"));
        btnAcc.setContentAreaFilled(false);
        btnAcc.setBorderPainted(false);
        btnAcc.setBounds(0, 0, 510, 780);
        pnl5.add(btnAcc);
        btnAcc.addActionListener(e -> {
            pnl1.setVisible(true);
            pnl2.setVisible(false);
            pnl3.setVisible(false);
            pnl4.setVisible(false);
            pnl5.setVisible(false);
            pnl6.setVisible(false);
        });

        // PANEL 6----------------------------------------------------------------------------------------------------
        pnl6 = new JPanel();
        pnl6.setLayout(null);
        pnl6.setBackground(Color.WHITE);
        pnl6.setBounds(0, 0, 510, 780);
        pnl6.setVisible(false);


        JButton btnMap = new JButton(new ImageIcon("Files/location233.png"));
        btnMap.setContentAreaFilled(false);
        btnMap.setBorderPainted(false);
        btnMap.setBounds(0, 0, 510, 780);
        pnl6.add(btnMap);
        btnMap.addActionListener(e -> {
            pnl1.setVisible(true);
            pnl2.setVisible(false);
            pnl3.setVisible(false);
            pnl4.setVisible(false);
            pnl5.setVisible(false);
            pnl6.setVisible(false);
        });



        mainFrm.add(bottomPnl);
        mainFrm.add(pnl1);
        mainFrm.add(pnl2);
        mainFrm.add(pnl3);
        mainFrm.add(pnl4);
        mainFrm.add(pnl5);
        mainFrm.add(pnl6);
        mainFrm.setVisible(true);
    }

    // Method to get appropriate greeting based on current time
    private String getGreetingMessage(String username) {
        String greeting;
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) {
            greeting = "Good Morning";
        } else if (hour < 18) {
            greeting = "Good Afternoon";
        } else {
            greeting = "Good Evening";
        }
        return String.format("<html>%s<br>%s</html>", greeting, username, " !"); // HTML for line break
    }

    public static void main(String[] args) {

        try {
            Font robotoFont = Font.createFont(Font.TRUETYPE_FONT, new java.io.File("path/to/Roboto-Regular.ttf"));
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(robotoFont);
        } catch (Exception e) {
            e.printStackTrace();
        }

        new AppMain();
    }
}
